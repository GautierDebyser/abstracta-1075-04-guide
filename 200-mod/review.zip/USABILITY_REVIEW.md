# First-time assembler review sheet

Status: **prepared, not conducted**. No participant results or usability claims are implied.

Guide: 200 Mod, Revision 1, October 30, 2026. Suggested session: 20–30 minutes, on the participant's usual phone or computer. Use a person unfamiliar with Abstracta. This is an instruction-comprehension review, not permission to perform unverified physical assembly.

## Facilitator procedure

Explain that the guide is being tested, not the participant. Ask them to think aloud. Present one task at a time without pointing at controls, explaining terminology, or correcting mistakes. Record their first action, pauses, incorrect interpretations and exact questions. Ask “What would you do next?” rather than suggesting an answer. Record any assistance only after allowing them to explain their interpretation. Do not ask them to hit, lift or load a physical unit during this review.

Record device/browser, viewport, participant familiarity and consent before starting. Avoid collecting unnecessary personal information. If feasible, repeat with a second unfamiliar person on a different device after revising the guide.

## Tasks and blank observations

| Task | First action / time to complete | Hesitation / error / exact words | Assistance given | Proposed revision |
|---|---|---|---|---|
| Identify the tube, connector types and tools needed for the first bone. | | | | |
| Find bone B on the plan; explain the direction of its unused prongs. | | | | |
| Start the step, slow it down, pause and scrub to inspect a connection. | | | | |
| Explain how the receiving bone moves when joining a pair of tubes. | | | | |
| Open full screen, exit, then explain whether progress was retained. | | | | |
| Mark a completion check, leave/reload the page, and resume the assembly. | | | | |
| Find the correct 620 corner placement and explain the missing-bumper example. | | | | |
| Switch to still instructions and identify all four bumpers before glass. | | | | |
| Use final inspection focus; explain what checking a box does and does not verify. | | | | |
| Explain the next assembly action and how to print the current checklist. | | | | |

## Debrief

- Which part required the most interpretation?
- Where did the guide and your expectation disagree?
- Could you identify when to stop and check orientation or support?
- What would you want beside you while physically assembling?

Prioritize repeated hesitation, wrong connector orientation, missing supports/bumpers and lost progress over cosmetic preferences. Save actual results in a separate dated report. Do not fill this sheet with simulated observations or claim a study occurred until real participants complete it.
